# Enterprise Knowledge AI Assistant — Database

## Overview
PostgreSQL stores application users, document metadata, extracted text chunks, access permissions, chat history, and optional safety observations. Original files are stored separately. ChromaDB stores embeddings; `document_chunks.vector_id` is intended to link a text chunk to its vector-store record.

## Tables
- `users`: users, roles, departments
- `documents`: file metadata and storage path
- `document_chunks`: extracted text and vector-store IDs
- `document_access`: document permissions per user
- `chat_sessions`: conversation sessions
- `chat_messages`: messages in a session
- `safety_observations`: optional hazard reports

## Setup
1. Create or select the PostgreSQL database configured by your team (for example, `enterprise_knowledge_db`).
2. Open pgAdmin Query Tool for that database.
3. Execute `schema.sql`.
4. Optionally execute `seed.sql` for fictional test data.
5. Verify tables with:

```sql
SELECT table_name
FROM information_schema.tables
WHERE table_schema = 'public' AND table_type = 'BASE TABLE'
ORDER BY table_name;
```

## Sample-data verification

```sql
SELECT 'users' AS table_name, COUNT(*) AS total FROM public.users
UNION ALL SELECT 'documents', COUNT(*) FROM public.documents
UNION ALL SELECT 'document_chunks', COUNT(*) FROM public.document_chunks
UNION ALL SELECT 'document_access', COUNT(*) FROM public.document_access
UNION ALL SELECT 'chat_sessions', COUNT(*) FROM public.chat_sessions
UNION ALL SELECT 'chat_messages', COUNT(*) FROM public.chat_messages
UNION ALL SELECT 'safety_observations', COUNT(*) FROM public.safety_observations
ORDER BY table_name;
```

## Notes
- Sample names/emails are fictional.
- `/uploads/...` paths are placeholders; this SQL does not upload files.
- `sample-safety-vector-001` is a placeholder, not a real ChromaDB embedding.
- Never commit passwords, API keys, confidential documents, or real employee data.
- Coordinate schema changes with teammates before merging.
