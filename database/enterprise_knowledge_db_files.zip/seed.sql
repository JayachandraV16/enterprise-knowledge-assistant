-- Fictional sample data. Run schema.sql first. File paths/vector IDs are placeholders.
INSERT INTO public.users (full_name, email, role, department)
VALUES ('Aarav Sharma', 'aarav@example.com', 'admin', 'IT'),
       ('Priya Patil', 'priya@example.com', 'employee', 'Engineering')
ON CONFLICT (email) DO NOTHING;

INSERT INTO public.documents (filename, file_type, storage_path, uploaded_by, status, description)
SELECT 'machine_safety.pdf', 'PDF', '/uploads/machine_safety.pdf', u.id, 'processed', 'Sample machine safety document'
FROM public.users u WHERE u.email = 'aarav@example.com'
AND NOT EXISTS (SELECT 1 FROM public.documents d WHERE d.filename = 'machine_safety.pdf');

INSERT INTO public.documents (filename, file_type, storage_path, uploaded_by, status, description)
SELECT 'engineering_guide.docx', 'DOCX', '/uploads/engineering_guide.docx', u.id, 'uploaded', 'Sample engineering guide'
FROM public.users u WHERE u.email = 'aarav@example.com'
AND NOT EXISTS (SELECT 1 FROM public.documents d WHERE d.filename = 'engineering_guide.docx');

INSERT INTO public.document_chunks (document_id, chunk_index, page_number, content, vector_id)
SELECT d.id, 0, 1, 'Always follow the documented machine safety procedures.', 'sample-safety-vector-001'
FROM public.documents d WHERE d.filename = 'machine_safety.pdf'
AND NOT EXISTS (SELECT 1 FROM public.document_chunks c WHERE c.document_id = d.id AND c.chunk_index = 0);

INSERT INTO public.document_access (document_id, user_id, access_level)
SELECT d.id, u.id, 'read'
FROM public.documents d CROSS JOIN public.users u
WHERE d.filename = 'machine_safety.pdf' AND u.email = 'priya@example.com'
ON CONFLICT (document_id, user_id) DO NOTHING;

INSERT INTO public.chat_sessions (user_id, title)
SELECT u.id, 'Machine Safety Questions'
FROM public.users u WHERE u.email = 'priya@example.com'
AND NOT EXISTS (SELECT 1 FROM public.chat_sessions s WHERE s.user_id = u.id AND s.title = 'Machine Safety Questions');

INSERT INTO public.chat_messages (session_id, sender, message)
SELECT s.id, 'user', 'What are the machine safety procedures?'
FROM public.chat_sessions s WHERE s.title = 'Machine Safety Questions'
AND NOT EXISTS (SELECT 1 FROM public.chat_messages m WHERE m.session_id = s.id AND m.message = 'What are the machine safety procedures?');
